<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Modal;
use App\Models\Booking;
use App\Models\Mode_rate;
use App\Models\Model_image;
use App\Models\City;
use App\Models\Currency;
use App\Models\Model_specification;
use App\Models\City_location;
use App\Models\Customer;
use App\Models\Setting;
use Illuminate\Support\Facades\DB;
use Crypt;
use App\Helpers\Helper;
use Auth;
use  Carbon\Carbon;
use Validator;
use Session;
use Illuminate\Support\Facades\URL;

class BookingController extends Controller
{

    public function get_info(Request $request)
    {
        $data = array();
        $model = array();
        $customer = array();
        
        try
        {
            // $id = Auth::guard('api')->user()->customer_id;
            $modelId = $request->input('model_id');
            $fetchModel = Modal::where('modal_id','=',$modelId)->first(); 
            $ModelImage = Model_image::where('model_id',$fetchModel->modal_id)->where('model_image_flag','=',0)->first();
            $modelSpec =  Model_specification::where('model_id','=',$fetchModel->modal_id)->get();
            $id = $request->input('customer_id');
            $parseInt = (int)$id;
            $fetchCust = Customer::where('customer_id','=',$parseInt)->first();
            $spec=array();
                foreach ($modelSpec as $resSpecs) {
                $specvl = $resSpecs->specs['spec_name'];
                $specImg = '/assets/uploads/specifications/icons/'.$resSpecs->specs['spec_icon'];
                array_push($spec,$specvl,$specImg);
                }
            $getTerms = Setting::where('id','=',1)->first();
            $getAdditionalInfo = Setting::where('id','=',2)->first();
            
          
            
            if($fetchCust)
            {
                $model['Model_id'] = $fetchModel->modal_id;
                $model['Model_Name'] = $fetchModel->modal_name;
                $model['Makers'] = $fetchModel->maker->maker_name;
                $model['Image'] = '/assets/uploads/models/'.$ModelImage->model_image;
                $model['specifications'] = $spec;
                // $data['specifications'] = $spec;
                $customer['Customer_id'] = $fetchCust->customer_id;
                $customer['Customer_first_name'] =  $fetchCust->cust_fname;
                $customer['Customer_Last_name'] =  $fetchCust->cust_lname;
                $customer['Mobile_code'] = $fetchCust->cust_mobile_code;
                $customer['Mobile_number'] = $fetchCust->cust_mobile_number;
                $customer['Date_of_birth'] = $fetchCust->cust_dob;
                $customer['Qatar_id'] = $fetchCust->cust_qatar_id;
                $customer['Passport_number']  = $fetchCust->cust_passport_number;
                $customer['Nationality'] = $fetchCust->nationality['country_name'];
                $customer['Address_line_1'] = $fetchCust->cust_address_line_1;
                $customer['Address_line_2'] = $fetchCust->cust_address_line_2;

            }
            //  array_push($data,$model); 
            // array_push($data,$customer); 
             $data['Model Details'] = $model;
              $data['Customer Information'] = $customer;
              $data['Terms_and_conditions_Line_1'] = strip_tags($getTerms->st_description);
            $data['Terms_and_conditions_Line_2'] = strip_tags($getTerms->st_description_line_2);
             $data['Additional_info_Line_1'] = strip_tags($getAdditionalInfo->st_description);
            $data['Additional_info_Line_2'] = strip_tags($getAdditionalInfo->st_description_line_2);
                           
            return response($data);
        }catch (\Exception $e) {
           $response = ['status' => '0', 'message' => $e->getMessage()];
           return response($response);
        }catch (\Throwable $e) {
            $response = ['status' => '0','message' => $e->getMessage()];

            return response($response);
        }
    }


    public function save(Request $request)
    {
        
    	$data = array();
        $frmDate = $request->input('book_from_date');
        // $countFromDate = Carbon::parse($fromDat); //for counting numbr of days 
        // $parseFromDate = Carbon::parse($fromDat)->format('Y-m-d');
        $toDate = $request->input('book_to_date');
        // $countToDt = Carbon::parse($toDat); //for counting number of days 
        // $parseToDt = Carbon::parse($toDat)->format('Y-m-d');
        $pickupTime = $request->input('book_pickup_time');
        // $parsePickTime = Carbon::parse($pickTime)->format('H:i:s'); //24 hours format
        $returnTime = $request->input('book_return_time');
        // $parseretnTime = Carbon::parse($retnTime)->format('H:i:s');
        $modelId = $request->input('book_car_model');
        $ftchMake = Modal::where('modal_id','=',$modelId)->first(); //get maker name 
        $makers = $ftchMake->maker->maker_name;
        
        $parseFrmDt = Helper::parseCarbon($frmDate); 
          $parseToDate = Helper::parseCarbon($toDate);
          $parsePickTime = Helper::parseCarbon($pickupTime);
          $parseRetTime = Helper::parseCarbon($returnTime);
          $diff = $parsePickTime->diffInHours($parseRetTime);
          $diffDays = $parseFrmDt->diffInDays($parseToDate);
          
          $combinedfrom = date('Y-m-d H:i:s', strtotime("$frmDate $pickupTime"));
          $combinedto = date('Y-m-d H:i:s', strtotime("$toDate $returnTime"));
          $parsecombinefrom = Helper::parseCarbon($combinedfrom); 
          $parsecombineto = Helper::parseCarbon($combinedto); 
          $diffDays2 = $parsecombinefrom->diffInDays($parsecombineto);
          $mins            = $parseRetTime->diffInMinutes($parsePickTime, true);
          $totMins = ($mins/60);
          
        
         
          //get number of days
          if($totMins > 4 && $diff <= 12  && $diffDays2 >= 1)
          {
             $days=$parseFrmDt->diffInDays($parseToDate)+1;  
          }else{
              $days=$parseFrmDt->diffInDays($parseToDate); 
          }
          
        // $days = $countFromDate->diffInDays($countToDt);
        
        $typoo = Helper::setType($days);
        $rateType = Mode_rate::where('rate_type_id','=',$typoo)->first();
        $fetchTypName = $rateType->rates->rate_type_code;
        $referIdCheck = Booking::latest('book_id')->first(); //check if any booking exist in tb and fetch its reference id
        if($referIdCheck->exists())
        {
            $fetchId = $referIdCheck->book_ref_id;
            $ReferId = $fetchId+1;
        }else{
            $ReferId ="34332";
        }
        $validator = Helper::validateBooking($request->all());
        if(!$validator->fails())
            {
                $datas= $request->except('_token');
                $currDetail = Booking::insertGetId($datas);
                Booking::where('book_id','=',$currDetail)->update([
                    'book_ref_id' => $ReferId,
                    'book_from_date' => $parseFrmDt,
                    'book_to_date' => $parseToDate,
                    'book_pickup_time' => $parsePickTime,
                    'book_return_time' => $parseRetTime, 
                    'book_total_days' => $days,
                    'book_car_rate_type' => $fetchTypName,
                    // 'payment_status' =>1,
                    'active_flag' =>1,
                    'book_status' =>1,  //pending // it will become confirmed only wen payment is completed
                    'created_at' =>\Carbon\Carbon::now(),
                    'updated_at' =>\Carbon\Carbon::now()
                ]);
                //payment gateway 
                
                
                	$orderid= $this->generateRandomString(6);
	        $merchant="DB95927"; 
        	$apipassword="afbc40219aa0e4eb35e3ebfd46d809e8"; 
	        $amount=$request->input('book_total_rate');
	        $returnUrl = URL::to('booking-success');
	        $currency = "QAR";

	       /* $url = "https://dohabank.gateway.mastercard.com/api/rest/version/57/merchant/DB95927/session";
	
        	$ch = curl_init($url);
        	curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
        	curl_setopt($ch, CURLOPT_USERPWD, "merchant.DB95927:afbc40219aa0e4eb35e3ebfd46d809e8");
        	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        	curl_setopt($ch, CURLOPT_POST, true);
        	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

        	$headers = array(
        	   "Authorization: Basic bWVyY2hhbnQuREI5NTkyNzphZmJjNDAyMTlhYTBlNGViMzVlM2ViZmQ0NmQ4MDllOA==",
        	   "Content-Type: application/json",
        	);
	
	
	        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$data1 = <<<DATA
{

    "apiOperation": "CREATE_CHECKOUT_SESSION",

    "interaction": {

        "operation": "PURCHASE"

    },

    "order"      : {

        "amount"     : "$amount",

        "currency"   : "$currency",

        "description": "Car Booking",

        "id": "$orderid"

    }

}
DATA;


curl_setopt($ch, CURLOPT_POSTFIELDS, $data1);

//for debug only!
//curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
//curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

$resp = curl_exec($ch);

$response = json_decode($resp);


// exit;
curl_close($ch);

$sessionid = $response->session->id;*/
$sessionid=rand(1000,9999);

                Booking::where('book_id','=',$currDetail)->update([
                    'book_ref_id' => $ReferId,
                    'payment_session_id' => $sessionid
                ]);

                
                //payment gateway end
                $bookingInfo = Booking::where('book_id','=',$currDetail)->first();
                
                $data['Booking_id'] = $currDetail;
                $data['Reference_id']   = $ReferId;
                $data['From_date'] =  $frmDate;
                $data['Pickup_Time'] = $pickupTime;
                $data['To_Date'] = $toDate;
                $data['Return_Time'] = $returnTime;
                $data['Daily_rate'] =  $request->input('book_daily_rate');
                $data['Total_rate'] = $request->input('book_total_rate');
                $data['Drop_fee']=  $request->input('drop_fee');
                $data['Country'] = $bookingInfo->country['country_name'];
                $data['City_Name'] = $bookingInfo->city['city_name'];
	    		$data['Location_Name'] = $bookingInfo->state['location_name'];
                $data['Additional_package'] = $request->input('additional_package');
                $data['Payment_session_id']  = $sessionid;
                $data['Payment_version']  = 57;
                $data['Payment_order_id'] = $orderid;
                $data['Booking_status'] = "Pending";
                $data['status']     = 1;
                $data['message']    = "Booking Success Awaiting Payment";
            }else{
                $data['errors'] = $validator->errors();
                $data['status'] = 0;
                $data['message'] = "Booking Failed";
            }
    	return response($data);
    }
    
    public function bookingSuccess(Request $request)
    {
        
        $data = array();
        $bookDetails = array();
        try {
            $referenceId = $request->booking_ref_id;
            //$orderId = $request->order_id;
            $sessionId = $request->session_id;
            if($sessionId!="")
            {
           
            $getBookInfo = Booking::where('book_ref_id','=',$referenceId)->first();
            if($getBookInfo)
            {
               Booking::where('book_ref_id','=',$referenceId)->update([
                'book_status' =>4, //confirmed
                ]); 
                $data['Booking_status']  = "Confirmed";
                $data['Booking_status_code']  = "4";
                $data['message'] = "Payment Success";
                $data['status'] = 1;
                $modelInfo = Modal::where('modal_id','=',$getBookInfo->book_car_model)->first();
                $model = array();
                    $model['Model_id']   = $getBookInfo->book_car_model;
                    $model['Model_name']   = $modelInfo->modal_name;
                    $model['Maker']   = $modelInfo->maker['maker_name'];
                    $model['Model_category'] = $modelInfo->category['model_cat_name'];
                    //specifications
                    $resSpec = Model_specification::where('model_id','=',$modelInfo->modal_id)->get();
                    $spec=array();
                  foreach ($resSpec as $resSpecs) {
                    $specComb[0] = $resSpecs->specs['spec_name'];
                    $specComb[1] = '/assets/uploads/specifications/icons/'.$resSpecs->specs['spec_icon'];
                    array_push($spec,$specComb);

                  }
                  $model['specifications'] = $spec;
                
                    $data['Reference_id']   = $getBookInfo->book_ref_id;
                    $data['From_date'] =  $getBookInfo->book_from_date;
                    $data['Pickup_Time'] = $getBookInfo->book_pickup_time->format('H:i:s');
                    $data['To_Date'] = $getBookInfo->book_to_date;
                    $data['Return_Time'] = $getBookInfo->book_return_time->format('H:i:s');
                    $data['Daily_rate'] =  $getBookInfo->book_daily_rate;
                    $data['Total_rate'] = $getBookInfo->book_total_rate;
                    $data['Drop_fee']=  $getBookInfo->drop_fee;
                    $data['Country'] = $getBookInfo->country['country_name'];
                    $data['City_Name'] = $getBookInfo->city['city_name'];
    	    		$data['Location_Name'] = $getBookInfo->state['location_name'];
                    $data['Additional_package'] = $getBookInfo->additional_package;
                    array_push($bookDetails,$model);
                     $data['Models'] = $bookDetails;
                
            }else{
                $data['Booking_status']  = "Pending";
                $data['message'] = "Reference Id/sessionId Does not Exist";
                $data['status'] = 0;
            }
            }else{
                $data['Booking_status']  = "Pending";
                $data['message'] = "No Session Id Recieved";
                $data['status'] = 0;
                
            }
            
            
           
        return response($data);

        }catch (\Exception $e) {
            
           $response = ['status' => '0', 'message' => $e->getMessage()];
           return response($response);
            
        }catch (\Throwable $e) {
            $response = ['status' => '0','message' => $e->getMessage()];

            return response($response);
        }
    }
    
    
    public function paymentCancel(Request $request)
    {
        $data = array();
        try {
            $referenceId = $request->booking_ref_id;
            //$orderId = $request->order_id;
            $sessionId = $request->session_id;
            if($sessionId!="")
            {
            $getBookInfo = Booking::where('book_ref_id','=',$referenceId)->first();
            if($getBookInfo)
            {
               Booking::where('book_ref_id','=',$referenceId)->update([
                'book_status' =>3, //payment failed
                ]); 
                $data['Booking_status']  = "Payment Failed";
                $data['Booking_status_code']  = "3";
                $data['status'] = 1;
                $data['message'] = "Payment Failed";
            }else{
                $data['Booking_status']  = "Pending";
                $data['status'] = 0;
                $data['message'] = "Reference Id/sessionId Does not Exist";
            }
            }else{
                $data['Booking_status']  = "Pending";
                $data['status'] = 0;
                $data['message'] = "No Session Id Recieved";
            }
            
            
           
        return response($data);

        }catch (\Exception $e) {
            
           $response = ['status' => '0', 'message' => $e->getMessage()];
           return response($response);
            
        }catch (\Throwable $e) {
            $response = ['status' => '0','message' => $e->getMessage()];

            return response($response);
        }
    }
    
    
    public function cancelBooking(Request $request)
    {
        $data = array();
        try {

            $BookingNumber = $request->booking_number;
            $CustomerId = $request->customer_id;

            //check if customer with such a booking exist
            $custCheck = Booking::where('book_cust_id','=',$CustomerId)->where('book_ref_id',$BookingNumber)->first();

            if($custCheck)
            {
                $curDate = \Carbon\Carbon::now();
                $cretdAt = $custCheck->created_at;
                $addDayss = $cretdAt->addDays(1);

            if($curDate<=$addDayss)
            {
                Booking::where('book_ref_id','=',$BookingNumber)->update([
                        'book_status' => 5,
                        'active_flag' => 0

                    ]);
               $data['status'] = 1;
               $data['Booking_status'] = "Cancelled";
               $data['is_Active '] = 0;
               $data['message'] = "Booking for Reference_id". $BookingNumber . " is Cancelled.";
               
                }else{
                     
                    $data['status'] = 0;
                    $data['message'] = "Time Exceeded. Unable to cancel Booking";
                }

            }else{
                $data['status'] = 0;
                $data['message'] = "No Such Booking Exist for the Customer";
            }

            return response($data);

            }catch (\Exception $e) {
           $response = ['status' => '0', 'message' => $e->getMessage()];
           return response($response);
        }catch (\Throwable $e) {
            $response = ['status' => '0','message' => $e->getMessage()];

            return response($response);
        }
    }
    
     public function bookAgainInfo(Request $request)
    {

        $data = array();
        $model = array();
        $customer = array();
        try {

                $customerId = $request->customer_id;
                $bookingRefId = $request->booking_reference_id;
                $frmDate = $request->from_date;
                $toDate = $request->to_date;
                $parseFrmDt = Helper::parseCarbon($frmDate); 
             $parseToDate = Helper::parseCarbon($toDate);
              $frmDt = $parseFrmDt->format('Y-m-d');
              $toDt = $parseToDate->format('Y-m-d');
              $secndParsFrm =Helper::parseCarbon($frmDt);
              $secndParseTo = Helper::parseCarbon($toDt);
            $pickTime = $parseFrmDt->format('H:i:s');
            $retTime = $parseToDate->format('H:i:s');
            $parsePickTime = Helper::parseCarbon($pickTime);
            $parseRetTime = Helper::parseCarbon($retTime);
            $diff = $parsePickTime->diffInHours($parseRetTime);
          $diffDays2 = $parseFrmDt->diffInDays($parseToDate);
          $mins            = $parseRetTime->diffInMinutes($parsePickTime, true);
          $totMins = ($mins/60);
                // $pickupTime = $request->input('pickup_time');
                // $returnTime = $request->input('return_time');
                $curType = $request->currency_id;

                $fetchPrvBooking = Booking::where('book_ref_id','=',$bookingRefId)->first();
                

                $modalId = $fetchPrvBooking->book_car_model;
               
                $locId = $fetchPrvBooking->book_bill_cust_location;
                $cityId = $fetchPrvBooking->book_bill_cust_city;
                $resCity =City::where('city_id','=',$cityId)->first(); //Get City
                $resLoc = City_location::where('city_loc_id','=',$locId)->first(); //Get Location

                //customer info
                $customer['First_name'] = $fetchPrvBooking->book_bill_cust_fname;
                $customer['Last_name'] = $fetchPrvBooking->book_bill_cust_lname;
                $customer['Date_of_Birth'] = $fetchPrvBooking->book_bill_cust_dob;
                $customer['From_Date'] = $frmDt;
                $customer['To_Date'] = $toDt;
                $customer['Pickup_Time'] = $pickTime;
                $customer['Return_Time'] = $retTime;
                $customer['Customer_Id'] = $fetchPrvBooking->book_cust_id;
                $customer['Mobile_code'] = $fetchPrvBooking->book_bill_cust_mobile_code;
                $customer['Mobile_Number'] = $fetchPrvBooking->book_bill_cust_mobile;
                $customer['Qatar Id'] = $fetchPrvBooking->book_bill_cust_qatar_id;
                $customer['Country'] = $fetchPrvBooking->book_bill_cust_nationality;
                $customer['Address_1'] = $fetchPrvBooking->book_bill_cust_address_1;
                $customer['Address_2'] = $fetchPrvBooking->book_bill_cust_address_2;
                $customer['Zipcode'] = $fetchPrvBooking->book_bill_cust_zipcode;
                $customer['Location'] = $resLoc->location_name;
                $customer['City'] = $resCity->city_name;


                //model details
 

             
          
          //get number of days
          if($totMins > 4 && $diff <= 12  && $diffDays2 >= 1)
          {
            $days=$secndParsFrm->diffInDays($secndParseTo)+1;  
          }else{
            $days=$secndParsFrm->diffInDays($secndParseTo); 
          } 
            //   $days=$parseFrmDt->diffInDays($parseToDate); 
              $data['Days'] = $days;
              $data['City'] = $resCity->city_name;
              $data['Location'] = $resLoc->location_name;

            if(!$days==0)
            {
              $modList= Modal::where('modal_id','=',$modalId)->first();
              $car=array();

                    $modalId = $modList->modal_id;
                    $car['Model_Id'] = $modalId;
                    $car['Model_name']=$modList->modal_name;
                    $car['Maker']=$modList->maker->maker_name;
                    $data['Model_category'] = $modList->category->model_cat_name;

                    $modImage = Model_image::where('model_id',$modList->modal_id)->where('model_image_flag','=',0)->first();
                    $car['Model_image'] = '/assets/uploads/models/'.$modImage->model_image;
                    //specifications
                    $resSpec = Model_specification::where('model_id','=',$modList->modal_id)->get();
                    $spec=array();
                      foreach ($resSpec as $resSpecs) {
                        $specComb[0] = $resSpecs->specs['spec_name'];
                        $specComb[1] = '/assets/uploads/specifications/icons/'.$resSpecs->specs['spec_icon'];
                        array_push($spec,$specComb);

                      }
                      $car['specifications'] = $spec;
                      $typoo = Helper::setType($days);
                      $rateType = Mode_rate::where('model_id','=',$modList->modal_id)->where('rate_type_id','=',$typoo)->get();
               
                   foreach ($rateType as $rateTypes) {
                    
                      $fetchrate = $rateTypes->rate; //get rate from the table //rate
                      $fetchOfferRate =Helper::checkOffer($rateTypes->model_rate_id,$modList->modal_id); //get offer rate from table
                      if($curType)
                       {
                          $fetchCurrency = Currency::where('currency_id','=',$curType)->first();
                          $car['Currency_code'] = $fetchCurrency->currency_code;
                          $curConvertRate = $fetchCurrency->currency_conversion_rate;

                          $mainOffer = $fetchOfferRate*$curConvertRate;
                          $mainRat = $fetchrate*$curConvertRate;

                          if($fetchOfferRate<$fetchrate)
                          {
                            $rate = $fetchOfferRate*$curConvertRate;
                          }else{
                            $rate = $fetchrate*$curConvertRate;
                          }
                        }
                       $car['Rate_code'] = $rateTypes->rates->rate_type_code;
                       // $car['Total_Rate'] = Helper::showList($days,$rate);
                        $rt = Helper::showList($days,$rate);

                       $car['Total_Rate'] = $rt['totValue'];

                       $car['Rate_per_day'] = number_format($rt['perDayRate'], 3, '.', '');
                       $car['Main_Rate']= $mainRat;
                       $car['Offer_Rate'] = $mainOffer;
                       
                     array_push($model,$car); 
                   
                     }
                     $data['status'] = 1;
                     $data['message'] = "success";
                     $data['Customer_Info'] = $customer;
                    $data['Model_Info'] = $model;

                     }else{
              $data['status'] = 0;
              $data['message'] = "No Cars available";
            }

                return response($data);

        }catch (\Exception $e) {
           $response = ['status' => '0', 'message' => $e->getMessage()];
           return response($response);
        }catch (\Throwable $e) {
            $response = ['status' => '0','message' => $e->getMessage()];

            return response($response);
        }



    }

    
     public function ViewEachBook(Request $request)
    {
       

         $data = array();
        try {

            $customerId = $request->customer_id;
            $bookingRefId = $request->booking_reference_id;

            //check if customer with such a booking exist
            $custCheck = Booking::where('book_cust_id','=',$customerId)->where('book_ref_id',$bookingRefId)->first();

            if($custCheck)
            {
                $data['status'] = 1;
                $data['Reference_id'] = $custCheck->book_ref_id;
                $data['Pickup_Date'] = $custCheck->book_from_date;
                $data['Return_Date'] = $custCheck->book_to_date;

                $data['Total_Days'] = $custCheck->book_total_days;

                $data['Rate_Per_Day'] = $custCheck->book_daily_rate;

                $data['Total_Rate'] = $custCheck->book_total_rate;
                $data['Customer_First_Name '] = $custCheck->book_bill_cust_fname;
                $data['Customer_Last_Name'] = $custCheck->book_bill_cust_lname;
                $data['Customer_Date_of_Birth'] = $custCheck->customer['cust_dob'];
                $data['Mobile_Number'] = $custCheck->customer['cust_mobile_number'];
                $data['Qatar_ID'] = $custCheck->customer['cust_qatar_id'];
                $data['Nationality'] = $custCheck->country['country_name'];
                $data['City'] = $custCheck->city['city_name'];
                $data['Location'] = $custCheck->state['location_name'];
                $data['Address_1'] = $custCheck->book_bill_cust_address_1;
                $data['Address_2'] = $custCheck->book_bill_cust_address_2;
                $data['Zipcode'] = $custCheck->book_bill_cust_zipcode;




            }else{
                $data['status'] = 0;
                $data['message'] = "No Such Booking Exist for the Customer";
            }

            return response($data);

        }catch (\Exception $e) {
           $response = ['status' => '0', 'message' => $e->getMessage()];
           return response($response);
        }catch (\Throwable $e) {
            $response = ['status' => '0','message' => $e->getMessage()];

            return response($response);
        }
    }
    
     public  function generateRandomString($length = 6) {
        $characters = '0123456789';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }
    
    public function termsConditions()
    {
        $data = array();
        try {
            
            $getData = Setting::where('id','=',1)->first();
            $data['status'] = 1;
            $data['message'] = "success";
            $data['Terms_and_conditions_Line_1'] = $getData->st_description;
            $data['Terms_and_conditions_Line_2'] = $getData->st_description_line_2;
        return response($data);

        }catch (\Exception $e) {
           $response = ['status' => '0', 'message' => $e->getMessage()];
           return response($response);
        }catch (\Throwable $e) {
            $response = ['status' => '0','message' => $e->getMessage()];

            return response($response);
        }
    }
    
    public function additionaInfo()
    {
        $data = array();
        try {
            
            $getData = Setting::where('id','=',2)->first();
            $data['status'] = 1;
            $data['message'] = "success";
            $data['Additional_info_Line_1'] = $getData->st_description;
            $data['Additional_info_Line_2'] = $getData->st_description_line_2;
        return response($data);

        }catch (\Exception $e) {
           $response = ['status' => '0', 'message' => $e->getMessage()];
           return response($response);
        }catch (\Throwable $e) {
            $response = ['status' => '0','message' => $e->getMessage()];

            return response($response);
        }
    }


    
}
