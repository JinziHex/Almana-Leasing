<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Booking;
use App\Models\Model_image;
use  Carbon;

class ReservationController extends Controller
{
    public function getReservations(Request $request)
    {
    	$data = array();
        $reserve = array();
        try
        	{
        		$custId = $request->input('customer_id');
        		$curDate = Carbon\Carbon::now();
        		$fetchBooking = Booking::where('book_cust_id','=',$custId)->where('book_to_date','>',$curDate)->get();
        		if(!$fetchBooking->isEmpty())
        		{
        		
        			foreach($fetchBooking as $fetchBookings)
	    			{
	    				$book = array();
	    				
	    				$book['Reference_id'] = $fetchBookings->book_ref_id;
	    				$book['From_date'] = $fetchBookings->book_from_date;
	    				$book['To_date'] = $fetchBookings->book_to_date;
	    				$book['Pickup_Time'] = date('g:i A',strtotime($fetchBookings->book_pickup_time));
	    				$book['Return_Time'] = date('g:i A',strtotime($fetchBookings->book_return_time));
	    				$book['First_name'] = @$fetchBookings->book_bill_cust_fname;
                        $book['Last_name'] = @$fetchBookings->book_bill_cust_lname;
                        $book['Mobile_Number'] = @$fetchBookings->book_bill_cust_mobile;
                        $book['Qatar Id'] = @$fetchBookings->book_bill_cust_qatar_id;
                        $book['Zipcode'] =  @$fetchBookings->book_bill_cust_zipcode;
                        $book['Date_of_Birth'] = @$fetchBookings->book_bill_cust_dob;
        				$book['booking_date']=date('Y-m-d',strtotime(@$fetchBookings->created_at));
        				$book['currency']="QAR";
	    				$book['Address_line_1'] = $fetchBookings->book_bill_cust_address_1;
	    				$book['Address_line_2'] = $fetchBookings->book_bill_cust_address_2;
	    				$book['Country_Id'] = $fetchBookings->book_bill_cust_nationality;
	    				$book['Country_Name'] = @$fetchBookings->country['country_name'];
	    				$book['City_Id'] = $fetchBookings->book_bill_cust_city;
	    				$book['City'] = @$fetchBookings->city['city_name'];
	    				$book['Location_Id'] = $fetchBookings->book_bill_cust_location;
	    				$book['Location'] = @$fetchBookings->state['location_name'];
	    				$book['Maker'] = @$fetchBookings->model->maker['maker_name'];
	    				$book['Model'] = @$fetchBookings->model->modal_name;
	                    $getImg = Model_image::where('model_id','=',$fetchBookings->book_car_model)->where('model_image_flag','=',0)->first();
	                     $book['Image'] ='/assets/uploads/models/'.$getImg->model_image; 
	                    $book['Total_days'] = $fetchBookings->book_total_days;
	                    $book['Booking_Status'] = $fetchBookings->status->status;
	    				$book['Daily Rate'] = $fetchBookings->book_daily_rate;
	    				$book['Total Rate'] = $fetchBookings->book_total_rate;
	    				array_push($reserve,$book);
	    			}
	    			$data['status'] = "1";
	    			 $data['Reservations'] = $reserve;
	    		}else{
	    			$data['status'] = "0";
	    			$data['message'] ="No reservations found";
	    		}
        		
        		
    			
        		return response($data);
	        }catch (\Exception $e) {
	           $response = ['status' =>"0", 'message' => $e->getMessage()];
	           return response($response);
	        }catch (\Throwable $e) {
	            $response = ['status' =>"0",'message' => $e->getMessage()];

	            return response($response);
	        }
    }
}
