@extends('admin.layouts.app')
@section('content')
<div class="right_col" role="main">
   <div class="">
      <div class="row">
         <div class="col-md-12 col-sm-12 ">
            <div class="x_panel">
               <div class="x_title">
                  <h2>{{$pageTitle}}</h2>
                  <div class="clearfix"></div>
               </div>
               <div class="x_content">
                  <form id="demo-form2" data-parsley-validate class="form-horizontal form-label-left" method="POST" action="{{route('admin.page-data.update')}}">
                     @csrf
                     @if(session('status'))
                     <div class="alert alert-success" id="err_msg">
                        <p>{{session('status')}}<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></p>
                     </div>
                     @endif 
                      <input type="hidden" value="{{$fetchDetail->page_data_id}}" name="page_data_id">
                     <div class="item form-group">
                        <label class="col-form-label col-md-3 col-sm-3 label-align">{{ __('Title')}}<span class="required">*</span></label>
                        <div class="col-md-6 col-sm-6 ">
                           <input type="text" class="form-control" required="" value="{{ $fetchDetail->page_title }}" name="page_title">
                        </div>
                     </div>
                     <div class="item form-group">
                        <label class="col-form-label col-md-3 col-sm-3 label-align">{{ __('Content Line 1')}}</label>
                        <div class="col-md-6 col-sm-6 ">
                           <textarea class="form-control" name="page_content" rows="5" cols="30"> {{$fetchDetail->page_content}} </textarea>
                        </div>
                     </div>
                     <div class="item form-group">
                        <label class="col-form-label col-md-3 col-sm-3 label-align">{{ __('Content Line 2')}}<span class="required">*</span></label>
                        <div class="col-md-6 col-sm-6 ">
                           <textarea class="form-control" required="" name="page_content_2" rows="5" cols="30"> {{$fetchDetail->page_content_2}} </textarea> 
                        </div>
                     </div>
                     
                     <div class="ln_solid"></div>
                     <div class="item form-group">
                        <div class="col-md-6 col-sm-6 offset-md-3">
                           <button type="submit" class="btn btn-success">{{ __('Update') }}</button>
                        </div>
                     </div>
                  </form>
               </div>
               <div class="clearfix"></div>
            </div>
         </div>
      </div>
   </div>
</div>
</div>
</div>
<script src="http://localhost:8000/assets/admin/vendors/jquery/dist/jquery.min.js"></script>
<script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
<script>
   CKEDITOR.replace( 'page_content_2' );
   CKEDITOR.replace( 'page_content' );
 </script>
@endsection